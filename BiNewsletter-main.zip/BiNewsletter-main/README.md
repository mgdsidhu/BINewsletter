# BiNewsletter
This is a newsletter app which is written on top of Python using data manipulation libraries like (Pandas, Seaborn, Plotly and Matplotlib) , output of this app we are sending by Email (email.mime) which is scheduled based on business requirement. 

We are generating SQL output summary based on 
 1) google.cloud 
 2) google.generativeai
    
which is useful to highlight the key insights and top performers for executive automatically.


Please find the attached final output of this app.

![Mail-BI-Newsletter](https://github.com/user-attachments/assets/8fee794a-7f17-4971-a79f-8ef87340dc75)
